package com.implementation;

public class BubbleSort {
    public static void sortArray(int[] arrayToSort) {
        // Bubble sort
        int arrayLength = arrayToSort.length;
        int temp = 0;
        int [] tempArray = arrayToSort;

        //Nested for loop
        for (int i = 0; i < arrayLength; i++) {
            for (int j = 1; j < (arrayLength - i); j++) {

                if (tempArray[j - 1] > tempArray[j]) {
                    temp = tempArray[j - 1];
                    tempArray[j - 1] = tempArray[j];
                    tempArray[j] = temp;
                }
            }
        }
    }
}
