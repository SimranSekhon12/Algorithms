package com.implementation;

public class MergeSort {
    private static int[] array;
    private static int[] tempMergeArray;
    private static int length;

    public static void sortArray(int[] arrayToSort) {
        int[] tempArray = arrayToSort;
        array = tempArray;
        length = tempArray.length;
        tempMergeArray = new int[length];
        mergeSort(0, tempArray.length - 1);
    }

    private static void mergeSort(int lowerIndex, int higherIndex) {

        if (lowerIndex < higherIndex) {
            int middle = lowerIndex + (higherIndex - lowerIndex) / 2;
            // Sort left side of the array
            mergeSort(lowerIndex, middle);

            // Sorts right side of the array
            mergeSort(middle + 1, higherIndex);

            // merge
            mergeParts(lowerIndex, middle, higherIndex);
        }
    }

    private static void mergeParts(int lowerIndex, int middle, int higherIndex) {

        for (int i = lowerIndex; i <= higherIndex; i++) {
            tempMergeArray[i] = array[i];
        }
        int i = lowerIndex;
        int j = middle + 1;
        int k = lowerIndex;
        while (i <= middle && j <= higherIndex) {
            if (tempMergeArray[i] <= tempMergeArray[j]) {
                array[k] = tempMergeArray[i];
                i++;
            } else {
                array[k] = tempMergeArray[j];
                j++;
            }
            k++;
        }
        while (i <= middle) {
            array[k] = tempMergeArray[i];
            k++;
            i++;
        }

    }
}
