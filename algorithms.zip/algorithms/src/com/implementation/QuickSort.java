package com.implementation;

public class QuickSort {
    static int [] arrayToSort;

    public static void prepareSort(int[] parsedArray){
        arrayToSort = parsedArray;

        int left = 0;
        int right = arrayToSort.length-1;

        //Sort array
        sortArray(left, right);
    }

    public static void sortArray(int left, int right) {

        if (left >= right)
            return;

        int pivot = arrayToSort[right];
        int partition = partition(left, right, pivot);

        sortArray(0, partition - 1);
        sortArray(partition + 1, right);
    }

    public static int partition(int left,int right,int pivot){
        int leftCursor = left-1;
        int rightCursor = right;
        while(leftCursor < rightCursor){
            while(arrayToSort[++leftCursor] < pivot);
            while(rightCursor > 0 && arrayToSort[--rightCursor] > pivot);
            if(leftCursor >= rightCursor){
                break;
            }else{
                swap(leftCursor, rightCursor);
            }
        }
        swap(leftCursor, right);
        return leftCursor;
    }

    public static void swap(int left,int right){
        int temp = arrayToSort[left];
        arrayToSort[left] = arrayToSort[right];
        arrayToSort[right] = temp;
    }
}
