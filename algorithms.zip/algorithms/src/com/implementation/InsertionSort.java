package com.implementation;

public class InsertionSort {
    public static void sortArray(int[] arrayToSort) {
        int temp;
        int[] tempArray = arrayToSort;
        for (int i = 1; i < tempArray.length; i++) {
            for (int j = i; j > 0; j--) {
                if (tempArray[j] < tempArray[j - 1]) {
                    temp = tempArray[j];
                    tempArray[j] = tempArray[j - 1];
                    tempArray[j - 1] = temp;
                }
            }
        }
    }
}
