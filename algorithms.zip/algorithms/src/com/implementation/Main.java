package com.implementation;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static int arrayLen;
    static long bubbleSortDuration, insertionSortDuration, heapSortDuration, mergeSortDuration, quickSortDuration, startTime, endTime = 0;

    public static void main(String[] args) {
        // write your code here
        requestUserInput();
    }

    public static void requestUserInput() {
        System.out.print("Enter the length of the array to be generated: ");
        try {
            Scanner scan = new Scanner(System.in);
            arrayLen = scan.nextInt();
            // call to generateArray
            generateArray(arrayLen);
            calculateAverageTime(bubbleSortDuration, "BubbleSort");
            calculateAverageTime(insertionSortDuration, "InsertionSort");
            calculateAverageTime(heapSortDuration, "HeapSort");
            calculateAverageTime(mergeSortDuration, "MergeSort");
            calculateAverageTime(quickSortDuration, "QuickSort");
        } catch (Exception e) {
            System.out.println("Array length must be an integer");
            requestUserInput();
        }
    }

    //    generate Array
    public static void generateArray(int arrayLen) {
        System.out.println("Sorting arrays of length " + arrayLen);
        for (int arrayCount = 0; arrayCount < 1000; arrayCount++) {

            int[] generatedArray = new int[arrayLen];
            for (int i = 0; i < arrayLen; i++) {
                Random rand = new Random();
                int randomNum = rand.nextInt(arrayLen * 10);
                generatedArray[i] = randomNum;
            }

            //Bubble Sort
            // Start time
            startTime = System.currentTimeMillis();
            // call to sort array
            BubbleSort.sortArray(generatedArray);
            //End time
            endTime = System.currentTimeMillis();
            //Duration
            bubbleSortDuration += (endTime - startTime);

            //Insertion Sort
            startTime = System.currentTimeMillis();
            // call to sort array
            InsertionSort.sortArray(generatedArray);
            //End time
            endTime = System.currentTimeMillis();
            //Duration
            insertionSortDuration += (endTime - startTime);

            //HeapSort
            startTime = System.currentTimeMillis();
            // call to sort array
            HeapSort.sortArray(generatedArray);
            //End time
            endTime = System.currentTimeMillis();
            //Duration
            heapSortDuration += (endTime - startTime);

            //MergeSort
            startTime = System.currentTimeMillis();
            // call to sort array
            MergeSort.sortArray(generatedArray);
            //End time
            endTime = System.currentTimeMillis();
            //Duration
            mergeSortDuration += (endTime - startTime);

            //Quick
            startTime = System.currentTimeMillis();
            // call to sort array
            QuickSort.prepareSort(generatedArray);
            //End time
            endTime = System.currentTimeMillis();
            //Duration
            quickSortDuration += (endTime - startTime);
        }
    }

    public static void calculateAverageTime(long timeTaken, String sortType) {
        System.out.print("Average Time of execution for " +sortType +" is ");
        double AverageTimeTaken = (double) timeTaken / 100;
        System.out.print(AverageTimeTaken + "milliseconds \n\n");
    }
}
