package com.implementation;

public class HeapSort {
    public static void sortArray(int arrayToSort[]) {
        int[] tempArray = arrayToSort;
        int temp, j, i;

        binaryHeap(tempArray);

        for (i = (tempArray.length) - 1; i > 0; ) {
            temp = tempArray[0];
            tempArray[0] = tempArray[i];
            tempArray[i] = temp;
            heapify(tempArray, 0, i--);
        }
    }

    public static void binaryHeap(int tempArray[]) {

        for (int i = (tempArray.length / 2) - 1; i >= 0; i--) {
            heapify(tempArray, i, tempArray.length);
        }

    }

    public static void heapify(int a[], int i, int n) {
        int l = 2 * i + 1;
        int r = 2 * i + 2;

        int temp, largest;

        if (l < n && a[l] > a[i])
            largest = l;
        else
            largest = i;

        if (r < n && a[r] > a[largest])
            largest = r;

        if (largest != i) {
            temp = a[largest];
            a[largest] = a[i];
            a[i] = temp;

            heapify(a, largest, n);
        }
    }
}
