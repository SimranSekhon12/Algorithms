<?php
	
	$con = new mysqli('localhost', 'root','','petstore');
	if ($con->connect_error) {
		printf("Connect failed: %s\n", $con->connect_error);
		exit();
	}
?>
<!DOCTYPE html>
<html>
<head lang="en">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" type="text/css" href="css/pet.css">
<title> Pet Store </title>
</head>

<body>
	<div class="my-site">
	<header>
		<h1> Pet Store </h1>
	</header>
	<div class="main-body">
		<div class="leftContent">
			<nav class="nav"> 
				<a href='index.html'>Home</a>
				<a href='AboutUs.html'>About Us</a>
				<a href='ContactUs.php'>Contact Us</a>
				<a href='Client.php'>Client</a>
				<a href='Service.php'>Service</a>
				<a href='Login.php'>Login</a>
			</nav>
		</div>

		<div class="rightContent">
			<div class="contactbg">

			</div>

			<div class="content">
				<h2> Contact Us </h2>
				<p> Required information is marked with an asterisk (*).</p>

				<form id="usrform" method="POST" action=".\ContactUs.php" onsubmit="validateForm()">
				<table class="table">

					<tr>
						<td>* First Name:</td>
						<td><input type="text" name="fname" required></td>
					</tr>

					<tr>
						<td>* Last Name:</td>
						<td><input type="text" name="lname" required></td>
					</tr>

					<tr>
						<td>* E-mail:</td>
						<td><input type="text" name="email" required></td>
					</tr>

					<tr>
						<td>Phone:</td>
						<td><input type="text" name="phone"></td>
					</tr>
					<tr>
						<td>* Comments:</td>
						<td><textarea name="comments"></textarea></td>
					</tr>
					<tr>
						<td><input type="submit" value="Add New One" name="submit"></td>	
					</tr> 
				</table>
				</form>

			</div>
			<footer>
				<small> <em>Copyright &copy; 2018 Pet Store</em></small> <br> 
				<a href='mailto:simran@sekhon.com'>simran@sekhon.com</a>
			</footer>
		</div>
	</div>
</div>
</body>
</html>

<?php

if(isset($_POST['submit']))
{
	
	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$comments=$_POST['comments'];
	
	
	$sql = "INSERT INTO `contactUs`(`fname`, `lname`, `email`, `phone`, `comments`) VALUES ('$fname','$lname','$email','$phone','$comments')";
	

	if ($con->query($sql) === TRUE) {
		echo "New record added successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $con->error;
		echo "error adding service !!!";
	}
		
}else {
		echo "error";
	}




$con->close();

?>