<?php

session_start();
?>
<?php
	
	$con = new mysqli('localhost', 'root','','petstore');
	if ($con->connect_error) {
		printf("Connect failed: %s\n", $con->connect_error);
		exit();
	}
?>

<!DOCTYPE html>
<html>
<head lang="en">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" type="text/css" href="css/pet.css">

<title> Login </title>
</head>

<body>
	<div class="my-site">
	<header>
		<h1> Pet Store </h1>
	</header>
	<div class="main-body">
		<div class="leftContent">
			<nav class="nav"> 
				<a href='index.html'>Home</a> 
				<a href='AboutUs.html'>About Us</a>
				<a href='ContactUs.php'>Contact Us</a>
				<a href='Client.php'>Client</a>
				<a href='Service.php'>Service</a>
				<a href='Login.php'>Login</a>
			</nav>
		</div>

		<div class="rightContent">
			<div class="headbg">

			</div>

			<div class="content">
				<h2> Login </h2>
				<p> Required information is marked with an asterisk (*).</p>

				<form id="usrform" method="POST" action=".\Login.php" onsubmit="validateForm()">
				<table class="table" cellspacing="0">

					<tr>
						<td>* E-mail:</td>
						<td><input type="text" name="email"></td>
					</tr>

					<tr>
						<td>* Password:</td>
						<td><input type="text" name="password"></td>
					</tr>
					<tr>
						<td><input type="submit" value="login" name="login"></td>	
					</tr> 
				</table>
				</form>

			</div>
			<footer>
				<small> <em>Copyright &copy; 2018 Pet Store</em></small> <br> 
				<a href='mailto:simran@sekhon.com'>simran@sekhon.com</a>
			</footer>
		</div>
	</div>
</div>
</body>
</html>

<?php
					
	if(isset($_POST['login']))
	{
		
		$email=$_POST['email'];
		$pass=$_POST['password'];
		
		if ($email=="") {
		
		echo "Email is empty";
		}
		elseif($pass=="")
		{
			echo "Password is empty";
		}
		else
		{
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  			echo "Invalid email format"; 
			}
			else
			{
				$sql = "SELECT * FROM users WHERE email='$email' AND password='$pass'";
				//$result = mysql_query($sql);
				$result = $con -> query($sql);
				echo "<br><br><br><br>";
				
					if ($result->num_rows > 0) {
						// output data of each row
						while($row = $result->fetch_assoc()) {
							echo "id: " . $row["userID"]. " - Name: " . $row["firstName"]. " " . $row["lastName"]. "<br>";
							
						if($row["Role"]==1){
								#session_start();
								$_SESSION['userID']=$row['userID'];
								$_SESSION['fName']=$row['fName'];
								$_SESSION['lName']=$row['lName'];
								header("location: AddClient.php");
							}else if($row["Role"]==0){
								#session_start();
								$_SESSION['userID']=$row['userID'];
								$_SESSION['fName']=$row['fName'];
								$_SESSION['lName']=$row['lName'];
								$_SESSION['businessName']=$row['businessName'];
								header("location: AddService.php");
							}
						}
					} else {
						echo "0 results";
					} 
				
				
				
			}
		}
	}

	mysqli_close($con);
?>
