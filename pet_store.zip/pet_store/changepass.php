<?php
session_start();
?>
<?php
	$con = new mysqli('localhost', 'root','','petstore');
	if ($con->connect_error) {
		printf("Connect failed: %s\n", $con->connect_error);
		exit();
	}
?>
<!DOCTYPE html>
<html>
<head lang="en">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" type="text/css" href="css/pet.css">
<title> Pet Store </title>
</head>

<body>
	<div class="my-site">
	<header>
		<h1> Pet Store </h1>
	</header>
	<div class="main-body">
		<div class="leftContent">
			<nav class="nav"> 
				<a href='logout.php'>Logout</a>
			</nav>
		</div>

		<div class="rightContent">
		<?php echo "User ID  " . $_SESSION["userID"] . ".<br>"; 
				
				 $fName = $_SESSION['fName'];
				 $lName = $_SESSION['lName'];
				
				?>
			<div class="headbg"> </div>

		
			<div class="content">
				<h2> Change Passwrd </h2>
				<p> Required information is marked with an asterisk (*).</p>

				<form method="POST" action=".\changepass.php">
				<table class="table">

					<tr>
						<td>* Old Password:</td>
						<td><input type="text" name="oldPassword" required></td>
					</tr>

					<tr>
						<td>* New Password:</td>
						<td><input type="text" name="newPassword" required></td>
					</tr>
					
					<tr>
						<td><input type="submit" value="Make Changes" name="reset"></td>	
					</tr> 
				</table>
				</form>

			</div>
			<footer>
				<small> <em>Copyright &copy; 2018 Pet Store</em></small> <br> 
				<a href='mailto:simran@sekhon.com'>simran@sekhon.com</a>
			</footer>
		</div>
	</div>
</div>
</body>
</html>

<?php
if(isset($_POST['reset'])) {
$oldPassword=$_POST['oldPassword'];
$newPassword1=$_POST['newPassword'];

    if(!$oldPassword==""|| !$newPassword1=="") {
        if($oldPassword!==$newPassword1) {
            
                $userID= "SELECT `userID` from `users` WHERE `password`= $oldPassword";
                $user_Id;
                $resultN = $con->query($userID);
                if ($resultN->num_rows > 0) {
                    if ($row = $resultN->fetch_assoc()) {
                        $user_Id = $row["userID"];
                    }
                } else {
                    echo "You entered wrong password!!!!";
                }


                $sql1="UPDATE `users` SET `password`='$newPassword1' WHERE `userID`=$user_Id";
				echo '$sql1';
                if ($con->query($sql1) === TRUE) {
                    echo 'Password Updated !!!!';        
                } else {
                    echo "Error: " . $query . "<br>" . $con->error;
                }
                
            
        } else { echo "Both Passwords are same"; } 
    } else{ echo "Please enter a password";}
}

?>