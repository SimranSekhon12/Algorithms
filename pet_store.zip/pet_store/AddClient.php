<!DOCTYPE html>
<html>
<head lang="en">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" type="text/css" href="css/pet.css">
<title> Pet Store </title>
</head>

<body>
	<div class="my-site">
	<header>
		<h1> Add Client </h1>
	</header>
	<div class="main-body">
		<div class="leftContent">
			<nav class="nav"> 
				<a href="#">My Pets</a>
				<a href="changepass.php">Update Password</a> 
				<a href="#">Update Address</a>
				<a href="#">Change Picture</a>
				<a href="logout.php">Logout</a>
			</nav>
		</div>

		<div class="rightContent">
			<div class="headbg"> </div>

		
			<div class="content">
				<h2> My Pet </h2>
				<p> Required information is marked with an asterisk (*).</p>

				<form>
				<table class="table">

					<tr>
						<td>*Client Name:</td>
						<td><input type="text" name="fname"></td>
					</tr>

					<tr>
						<td>*My Pet:</td>
						<td><input type="text" name="lname"></td>
					</tr>
					
					<tr>
						<td><input type="submit" value="Add New One" name="submit"></td>	
					</tr> 
				</table>
				</form>

			</div>
			<footer>
				<small> <em>Copyright &copy; 2018 Pet Store</em></small> <br> 
				<a href='mailto:simran@sekhon.com'>simran@sekhon.com</a>
			</footer>
		</div>
	</div>
</div>
</body>




</html>