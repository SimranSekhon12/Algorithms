package selenium;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import cmn.EventCatering_Functions;
import event_management.data.EventDAO;
import event_management.data.UserDAO;
import event_management.model.Event;
import event_management.model.User;
import event_management.util.CmnUtil;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(JUnitParamsRunner.class)
public class AdminTest {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	public static Properties prop = EventCatering_Functions.prop;
	EventCatering_Functions ecFunction = new EventCatering_Functions();
	private static List<String> HEADERS = Arrays.asList("Last Name", "First Name", "Username", "Role", "View",
			"Delete?");

	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);	
		
	}
	
	@Test
	@FileParameters("resources/selenium/admin_login_selenium.csv")
	  public void T01_adminLogin(String testCaseNo, String username, String password, String UnError, String PassError) throws Exception {
	    
		  ecFunction.login(driver, username, password);
		  ecFunction.takeScreenshot(driver, "t1_AdminLogin"+testCaseNo);
	    if (!CmnUtil.isNullorEmpty(UnError) || !CmnUtil.isNullorEmpty(PassError)) {
	    assertEquals(UnError, driver.findElement(By.xpath(prop.getProperty("Msg_Uname_Xpath"))).getText());
	    assertEquals(PassError, driver.findElement(By.xpath(prop.getProperty("Msg_Pass_Xpath"))).getText());
	    ecFunction.takeScreenshot(driver, "T01_adminLogin"+testCaseNo);
	    }
	    else {
	    	
	    	assertTrue(isElementPresent(By.xpath(prop.getProperty("Txt_ReservedEvents_Link"))));
	    	assertTrue(isElementPresent(By.linkText(prop.getProperty("Txt_Logout_Link"))));
	    	assertTrue(isElementPresent(By.linkText(prop.getProperty("Txt_EventCateringSys_Link"))));
	    	ecFunction.logout(driver);
		}
	  }
	
	@Test
	@FileParameters("resources/selenium/search_user_selenium.csv")
	public void T02_searchUser(String testCaseNo, String lastName,String error ) throws Exception {
		
		
		
		ecFunction.login(driver, prop.getProperty("ADMIN_USERNAME"), prop.getProperty("ADMIN_PASSWORD"));
	    
	    driver.findElement(By.cssSelector("span")).click();
	    
	    driver.findElement(By.name(prop.getProperty("Txt_LastName"))).sendKeys(lastName);
	    
	    driver.findElement(By.cssSelector(prop.getProperty("BTN_CSS_SUBMIT"))).click();
	    
	    ecFunction.takeScreenshot(driver, "t2_Adminsearch"+testCaseNo);
	    
	    if (!CmnUtil.isNullorEmpty(error)) {
	    	assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Admin_Lastname_error"))).getText());
	    }
	    else {
	    	
	    	List<WebElement> rows = driver.findElement(By.xpath(prop.getProperty("TBLE_XPATH")))
					.findElements(By.tagName("tr"));
			User user = new User();
			user.setLastName(lastName);
			
			
			
			List<User> userList = UserDAO.getUserByLastName(user);
			System.out.println("this"+userList);
			assertEquals(userList.size(), rows.size() - 1);
			validateHeaders();
			List<Map<String, String>> tableData = getTableData(2, rows.size());
 			assertTrue(compareDBResults(tableData, userList,lastName));
 			int i=2;
 			if ( i <= rows.size()) {				

 				driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[5]/a")).click();
 				assertEquals(userList.get(i - 2).getUtaId(),
 						driver.findElement(By.xpath(prop.getProperty("ADM_UTAID"))).getAttribute("value"));
 				assertEquals(userList.get(i - 2).getFirstName(),
 						driver.findElement(By.xpath(prop.getProperty("ADM_FIRSTNAME"))).getAttribute("value"));
 				assertEquals(userList.get(i - 2).getLastName(),
 						driver.findElement(By.xpath(prop.getProperty("ADM_LASTNAME"))).getAttribute("value"));
 				assertEquals(userList.get(i - 2).getUsername(),
 						driver.findElement(By.xpath(prop.getProperty("ADM_USERNAME"))).getAttribute("value"));
 				assertEquals(userList.get(i - 2).getPassword(),
 						driver.findElement(By.xpath(prop.getProperty("ADM_PASSWORD"))).getAttribute("value"));
 				assertEquals(userList.get(i - 2).getPhone(),
 						driver.findElement(By.xpath(prop.getProperty("ADM_PHONE"))).getAttribute("value"));
 				assertEquals(userList.get(i - 2).getEmail(),
 						driver.findElement(By.xpath(prop.getProperty("ADM_EMAIL"))).getAttribute("value"));
 				assertEquals(userList.get(i - 2).getStreetNumber(),
 						driver.findElement(By.xpath(prop.getProperty("ADM_STREETNUMBER"))).getAttribute("value"));
 				assertEquals(userList.get(i - 2).getStreetName(),
 						driver.findElement(By.xpath(prop.getProperty("ADM_STREETNAME"))).getAttribute("value"));
 				assertEquals(userList.get(i - 2).getCity(),
 						driver.findElement(By.xpath(prop.getProperty("ADM_CITY"))).getAttribute("value"));
 				assertEquals(userList.get(i - 2).getState(),
 						driver.findElement(By.xpath(prop.getProperty("ADM_STATE"))).getAttribute("value"));
 				assertEquals(userList.get(i - 2).getZipCode(),
 						driver.findElement(By.xpath(prop.getProperty("ADM_ZIPCODE"))).getAttribute("value"));
 				
 				assertEquals(userList.get(i - 2).getRole(),
 						new Select(driver.findElement(By.xpath(prop.getProperty("ADM_ROLE"))))
								.getFirstSelectedOption().getAttribute("value"));
					
 				driver.findElement(By.xpath(prop.getProperty("ADM_FIRSTNAME"))).clear();;
 				driver.findElement(By.xpath(prop.getProperty("ADMIN_FNAME_F"))).click();
 				driver.findElement(By.xpath(prop.getProperty("ADM_FIRSTNAME"))).sendKeys(userList.get(i - 2).getFirstName());
 				driver.findElement(By.xpath(prop.getProperty("ADMIN_FNAME_F"))).click();

 				ecFunction.takeScreenshot(driver, "t2_Admin_view_user"+(i-1));
 				
 				
	    	
	    }
 			
 			ecFunction.logout(driver);
 		    
 		   
	    }
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    

	    
	    
   
	  }
	
	
	
	
	private boolean compareDBResults(List<Map<String, String>> tableData, List<User> userList,String lastName) {
		
		for (int i = 0; i < userList.size(); i++) {
			if (!userList.get(i).getLastName().equals(tableData.get(i).get(HEADERS.get(0)))
					|| !userList.get(i).getFirstName().equals(tableData.get(i).get(HEADERS.get(1)))
					|| !userList.get(i).getUsername().equals(tableData.get(i).get(HEADERS.get(2)))
					|| !userList.get(i).getRole().equals(tableData.get(i).get(HEADERS.get(3)))
					|| !userList.get(i).getLastName().startsWith(lastName))    //starts with the given String
				
					
					{
				return false;
			}
		}
		
		return true;
	}

	private List<Map<String, String>> getTableData(int start, int end) {
		List<Map<String, String>> list = new ArrayList<>();
		for (int i = start; i <= end; i++) {
			Map<String, String> map = new HashMap<String, String>();
			map.put(HEADERS.get(0),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[1]")).getText());
			map.put(HEADERS.get(1),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[2]")).getText());
			map.put(HEADERS.get(2),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[3]")).getText());
			map.put(HEADERS.get(3),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[4]")).getText());
			
			list.add(map);
		}
		return list;

	}



	private void validateHeaders() {
		List<String> pageHeaders = new ArrayList<String>();
		for (int i = 1; i <= 6; i++) {
			String header = driver.findElement(By.xpath("html/body/table/tbody/tr[1]/th[" + i + "]")).getText();
			pageHeaders.add(header);
		}
		assertArrayEquals(HEADERS.toArray(), pageHeaders.toArray());
	}
	
	

	
	@Test
	@FileParameters("resources/selenium/delete_user_selenium.csv")
	public void T03_DeleteUser(String testCaseNo, String lastName ) throws Exception {
		
		ecFunction.login(driver, prop.getProperty("ADMIN_USERNAME"), prop.getProperty("ADMIN_PASSWORD"));
	    
	    driver.findElement(By.cssSelector("span")).click();
	    
	    driver.findElement(By.name("lastName")).sendKeys(lastName);
	    driver.findElement(By.cssSelector("input[type=\"submit\"]")).click();
	    
	    User user = new User();
	    user.setLastName(lastName);
	    
	    List<User> userList = UserDAO.getUserByLastName(user);
	    
	    
	    if(userList.size() > 0) {
	    driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[6]/a")).click();
	    
	    if(isAlertPresent()){
	    	
            System.out.println(isAlertPresent());
            
            //driver.switchTo().alert().accept();
            assertTrue(closeAlertAndGetItsText().matches("^Are you sure[\\s\\S]$"));
        }
	    ecFunction.takeScreenshot(driver, "t3_Delete_user_results"+testCaseNo);	    
	    assertTrue(driver.findElement(By.xpath("html/body/form/span")).getText().contains("user Deleted Successfully"));
	    }
	    else
	    {
	    	assertEquals("No Records found", driver.findElement(By.xpath(prop.getProperty("Admin_Lastname_error"))).getText());
	    }
	    
	    
	    
	    
	    
	    
	    
	    
	    
		
	}
	
	@Test
	  public void T04_validatePageButtonLink()  {
		  driver.get(prop.getProperty("URL_BASE") + prop.getProperty("URL_APP"));
		  //ecFunction.takeScreenshot(driver, "T01_testvalidateMainAppPage"+1);
		  
		  assertTrue(isElementPresent(By.linkText(prop.getProperty("Txt_EventCateringSys_Link"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Register_link"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Login_Link"))));
		  
		  driver.findElement(By.xpath(prop.getProperty("Login_Link"))).click();
		  assertTrue(isElementPresent(By.linkText(prop.getProperty("Txt_EventCateringSys_Link"))));
		  assertTrue(isElementPresent(By.cssSelector("form[name=\"companyForm\"] > table > tbody > tr > td")));
		  assertTrue(isElementPresent(By.xpath("//tr[2]/td")));
		  assertTrue(isElementPresent(By.cssSelector("input[type=\"submit\"]")));
		  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_Username"))));
		  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_Password"))));
		  ecFunction.login(driver, prop.getProperty("ADMIN_USERNAME"), prop.getProperty("ADMIN_PASSWORD"));
		  assertTrue(isElementPresent(By.linkText("Event Catering System")));
		  
		 
		  assertTrue(isElementPresent(By.xpath("html/body/div[2]/div/ul/li/a/span")));
		  assertTrue(isElementPresent(By.linkText("Log Out")));
		  
		  driver.findElement(By.xpath("html/body/div[2]/div/ul/li/a/span")).click();
		  assertTrue(isElementPresent(By.linkText("Event Catering System")));
		  assertTrue(isElementPresent(By.linkText("Log Out")));
		  assertTrue(isElementPresent(By.cssSelector("td")));
		  assertTrue(isElementPresent(By.cssSelector("input[type=\"submit\"]")));
		  
		  assertTrue(isElementPresent(By.name(prop.getProperty("ADMN_TXT_LASTNAME"))));
		  driver.findElement(By.name("lastName")).clear();
		    driver.findElement(By.name("lastName")).sendKeys("S");
		    driver.findElement(By.cssSelector("input[type=\"submit\"]")).click();
		    driver.findElement(By.linkText("View")).click();
		    
		    
		  //Labels
		    assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_UtaId_Xpath"))));
			  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_FirstName_Xpath"))));
			  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_LastName_Xpath"))));
			  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_UserName_Xpath"))));
			  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_Password_Xpath"))));
			  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_Phone_Xpath"))));
			  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_Email_Xpath"))));
			  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_StreetNo_Xpath"))));
			  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_StreetName_Xpath"))));
			  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_City_Xpath"))));
			  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_State_Xpath"))));
			  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_Zipcode_Xpath"))));
			  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_Role_Xpath"))));
			 
			  
			//Textboxes
			  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_UtaId"))));
			  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_FirstName"))));
			  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_LastName"))));
			  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_Username"))));
			  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_Password"))));
			  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_Phone"))));
			  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_Email"))));
			  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_StreetNo"))));
			  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_StreetName"))));
			  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_City"))));
			  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_State"))));
			  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_Zipcode"))));
			  
			//Dropdown
			  assertTrue(isElementPresent(By.id(prop.getProperty("Txt_Role"))));
		  
		  
		  
		  
		  
			    ecFunction.takeScreenshot(driver, "T04_validatePageButtonLink");

		  
		  
		  
		  }
		  
		 

		
		  
		  
		  
		  
		  
		  
	
	


	
	
	
	
	
	
	
	
	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
	
	private String closeAlertAndGetItsText() {
	    try {
	      Alert alert = driver.switchTo().alert();
	      String alertText = alert.getText();
	      if (acceptNextAlert) {
	        alert.accept();
	      } else {
	        alert.dismiss();
	      }
	      return alertText;
	    } finally {
	      acceptNextAlert = true;
	    }
	  }
	protected boolean isAlertPresent() {
        try {
          driver.switchTo().alert();
          return true;
        } catch (NoAlertPresentException e) {
          return false;
        }
      }



	
	
	
	
	
	
}





