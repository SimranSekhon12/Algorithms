package selenium;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import cmn.EventCatering_Functions;
import event_management.data.EventDAO;
import event_management.data.UserDAO;
import event_management.model.Event;
import event_management.model.User;
import event_management.util.CmnUtil;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(JUnitParamsRunner.class)
public class ManagerTest {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	public static Properties prop = EventCatering_Functions.prop;
	EventCatering_Functions ecFunction = new EventCatering_Functions();
	private static List<String> HEADERS = Arrays.asList("Event Name", "Date", "Start Time", "Duration", "Hall Name",
			"Event Status", "Estimated Cost", "Action");

	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
		driver = new FirefoxDriver();
		baseUrl = "http://localhost:8080/";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	
	@Test
	  public void T01_testvalidateMainAppPage()  {
		  driver.get(prop.getProperty("URL_BASE") + prop.getProperty("URL_APP"));
		  ecFunction.takeScreenshot(driver, "T01_testvalidateMainAppPage"+1);
		  
		  assertTrue(isElementPresent(By.linkText(prop.getProperty("Txt_EventCateringSys_Link"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Register_link"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Login_Link"))));
		  
	  }
	
	 @Test
	  public void T02_testvalidateRegisterPage()  {
		  
		  driver.get(prop.getProperty("URL_BASE") + prop.getProperty("URL_APP"));
		  driver.findElement(By.xpath(prop.getProperty("Register_link"))).click();
		  ecFunction.takeScreenshot(driver, "ManagerRegisterPageValidate"+1);
		  
		  assertTrue(isElementPresent(By.linkText(prop.getProperty("Txt_EventCateringSys_Link"))));
		  
		  //Labels
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_UtaId_Xpath"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_FirstName_Xpath"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_LastName_Xpath"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_UserName_Xpath"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_Password_Xpath"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_Phone_Xpath"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_Email_Xpath"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_StreetNo_Xpath"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_StreetName_Xpath"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_City_Xpath"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_State_Xpath"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_Zipcode_Xpath"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_Role_Xpath"))));
		  assertTrue(isElementPresent(By.xpath(prop.getProperty("Lbl_Mandatory_Xpath"))));
		  
		  //Textboxes
		  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_UtaId"))));
		  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_FirstName"))));
		  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_LastName"))));
		  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_Username"))));
		  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_Password"))));
		  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_Phone"))));
		  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_Email"))));
		  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_StreetNo"))));
		  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_StreetName"))));
		  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_City"))));
		  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_State"))));
		  assertTrue(isElementPresent(By.name(prop.getProperty("Txt_Zipcode"))));
		  
		  //Dropdown
		  assertTrue(isElementPresent(By.id(prop.getProperty("Txt_Role"))));
		  
		  //Button
		  assertTrue(isElementPresent(By.cssSelector(prop.getProperty("BTN_REGISTER_CSS"))));
		  ecFunction.takeScreenshot(driver, "T02_testvalidateRegisterPage"+1);

	  	  
	  }
	 
	 @Test
	  @FileParameters("resources/selenium/uta_id_selenium.csv")
	  public void T03_testUtaId(String testCaseNo, String utaId, String username, String password, String firstName, String lastName,
				String email, String phone, String zipCode, String streetName, String streetNumber, String state,
				String role, String city, String error) throws Exception {
		  
		  ecFunction.register(driver, utaId, username, password, firstName, lastName, email, phone, zipCode, streetName, streetNumber, 
				  state, role, city, error);
		  ecFunction.takeScreenshot(driver, "T03_testUtaId"+testCaseNo);
		  
		  assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Msg_UtaId_Xpath"))).getText());
	  }
	 
	 @Test
	  @FileParameters("resources/selenium/first_name_selenium.csv")
	  public void T04_testFirstName(String testCaseNo, String utaId, String username, String password, String firstName, String lastName,
				String email, String phone, String zipCode, String streetName, String streetNumber, String state,
				String role, String city, String error) throws Exception {
	    
		 
		 ecFunction.register(driver, utaId, username, password, firstName, lastName, email, phone, zipCode, streetName, streetNumber, 
				  state, role, city, error);
		 ecFunction.takeScreenshot(driver, "T04_testFirstName"+testCaseNo);
		  assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Msg_FirstName_Xpath"))).getText());
	    
	  }
	 
	 @Test
	  @FileParameters("resources/selenium/last_name_selenium.csv")
	  public void T05_testLastName(String testCaseNo, String utaId, String username, String password, String firstName, String lastName,
				String email, String phone, String zipCode, String streetName, String streetNumber, String state,
				String role, String city, String error) throws Exception {
	    
		 ecFunction.register(driver, utaId, username, password, firstName, lastName, email, phone, zipCode, streetName, streetNumber, 
				  state, role, city, error);
		 ecFunction.takeScreenshot(driver, "T05_testLastName"+testCaseNo);
		  assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Msg_LastName_Xpath"))).getText());
	    
	  }
	 
	 @Test
	  @FileParameters("resources/selenium/uname_selenium.csv")
	  public void T06_testUsername(String testCaseNo, String utaId, String username, String password, String firstName, String lastName,
				String email, String phone, String zipCode, String streetName, String streetNumber, String state,
				String role, String city, String error) throws Exception {
	    
		 ecFunction.register(driver, utaId, username, password, firstName, lastName, email, phone, zipCode, streetName, streetNumber, 
				  state, role, city, error);
		 ecFunction.takeScreenshot(driver, "T06_testUsername"+testCaseNo);
		  assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Msg_Username_Xpath"))).getText());
	    
	  }
	  
	  
	  @Test
	  @FileParameters("resources/selenium/password_selenium.csv")
	  public void T07_testPassword(String testCaseNo, String utaId, String username, String password, String firstName, String lastName,
				String email, String phone, String zipCode, String streetName, String streetNumber, String state,
				String role, String city, String error) throws Exception {
	    
		  ecFunction.register(driver, utaId, username, password, firstName, lastName, email, phone, zipCode, streetName, streetNumber, 
				  state, role, city, error);
		  ecFunction.takeScreenshot(driver, "T07_testPassword"+testCaseNo);
		  assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Msg_Password_Xpath"))).getText());
	  }
	  
	  
	  @Test
	  @FileParameters("resources/selenium/phone_number_selenium.csv")
	  public void T08_testPhone(String testCaseNo, String utaId, String username, String password, String firstName, String lastName,
				String email, String phone, String zipCode, String streetName, String streetNumber, String state,
				String role, String city, String error) throws Exception {
	    
		  ecFunction.register(driver, utaId, username, password, firstName, lastName, email, phone, zipCode, streetName, streetNumber, 
				  state, role, city, error);
		  ecFunction.takeScreenshot(driver, "T08_testPhone"+testCaseNo);
		  assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Msg_Phone_Xpath"))).getText());
	  }
	  
	  
	 
	  @Test
	  @FileParameters("resources/selenium/email_selenium.csv")
	  public void T09_testEmail(String testCaseNo, String utaId, String username, String password, String firstName, String lastName,
				String email, String phone, String zipCode, String streetName, String streetNumber, String state,
				String role, String city, String error) throws Exception {
	    
		  ecFunction.register(driver, utaId, username, password, firstName, lastName, email, phone, zipCode, streetName, streetNumber, 
				  state, role, city, error);
		  ecFunction.takeScreenshot(driver, "T09_testEmail"+testCaseNo);
		  assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Msg_Email_Xpath"))).getText());
	  }
	  
	  
	  
	  @Test
	  @FileParameters("resources/selenium/street_selenium.csv")
	  public void T10_testStreetNo(String testCaseNo, String utaId, String username, String password, String firstName, String lastName,
				String email, String phone, String zipCode, String streetName, String streetNumber, String state,
				String role, String city, String error) throws Exception {
	    
		  ecFunction.register(driver, utaId, username, password, firstName, lastName, email, phone, zipCode, streetName, streetNumber, 
				  state, role, city, error);
		  ecFunction.takeScreenshot(driver, "T10_testStreetNo"+testCaseNo);
		  assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Msg_StreetNo_XPath"))).getText());
	  }
	 
	  @Test
	  @FileParameters("resources/selenium/st_name_selenium.csv")
	  public void T11_testStreetName(String testCaseNo, String utaId, String username, String password, String firstName, String lastName,
				String email, String phone, String zipCode, String streetName, String streetNumber, String state,
				String role, String city, String error) throws Exception {
	    
		  ecFunction.register(driver, utaId, username, password, firstName, lastName, email, phone, zipCode, streetName, streetNumber, 
				  state, role, city, error);
		  ecFunction.takeScreenshot(driver, "T11_testStreetName"+testCaseNo);
		  assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Msg_StreetName_Xpath"))).getText());
	  }
	  
	  
	  @Test
	  @FileParameters("resources/selenium/city_selenium.csv")
	  public void T12_testCity(String testCaseNo, String utaId, String username, String password, String firstName, String lastName,
				String email, String phone, String zipCode, String streetName, String streetNumber, String state,
				String role, String city, String error) throws Exception {
	    
		  ecFunction.register(driver, utaId, username, password, firstName, lastName, email, phone, zipCode, streetName, streetNumber, 
				  state, role, city, error);
		  ecFunction.takeScreenshot(driver, "T12_testCity"+testCaseNo);
		  assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Msg_City_Xpath"))).getText());
	  }
	  
	  @Test
	  @FileParameters("resources/selenium/state_selenium.csv")
	  public void T13_testState(String testCaseNo, String utaId, String username, String password, String firstName, String lastName,
				String email, String phone, String zipCode, String streetName, String streetNumber, String state,
				String role, String city, String error) throws Exception {
	    
		  ecFunction.register(driver, utaId, username, password, firstName, lastName, email, phone, zipCode, streetName, streetNumber, 
				  state, role, city, error);
		  ecFunction.takeScreenshot(driver, "T13_testState"+testCaseNo);
		  assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Msg_State_Xpath"))).getText());
	  }
	  
	  @Test
	  @FileParameters("resources/selenium/zip_code_selenium.csv")
	  public void T14_testZipCode(String testCaseNo, String utaId, String username, String password, String firstName, String lastName,
				String email, String phone, String zipCode, String streetName, String streetNumber, String state,
				String role, String city, String error) throws Exception {
	    
		  ecFunction.register(driver, utaId, username, password, firstName, lastName, email, phone, zipCode, streetName, streetNumber, 
				  state, role, city, error);
		  ecFunction.takeScreenshot(driver, "T14_testZipCode"+testCaseNo);
		  assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Msg_Zipcode_Xpath"))).getText());
	  }
	  
	  @Test
	  @FileParameters("resources/selenium/role_selenium.csv")
	  public void T15_testRole(String testCaseNo, String utaId, String username, String password, String firstName, String lastName,
				String email, String phone, String zipCode, String streetName, String streetNumber, String state,
				String role, String city, String error) throws Exception {
	    
		  ecFunction.register(driver, utaId, username, password, firstName, lastName, email, phone, zipCode, streetName, streetNumber, 
				  state, role, city, error);
		  ecFunction.takeScreenshot(driver, "T15_testRole"+testCaseNo);
		  if (!CmnUtil.isNullorEmpty(error))
			  assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Msg_Role_Xpath"))).getText());
		  else
		  {
			  assertTrue(isElementPresent(By.linkText(prop.getProperty("Txt_EventCateringSys_Link"))));
			  assertTrue(isElementPresent(By.xpath(prop.getProperty("Register_link"))));
			  assertTrue(isElementPresent(By.xpath(prop.getProperty("Login_Link"))));
		  }
	  }
	 
	 
	  @Test
	  @FileParameters("resources/selenium/manager_login_selenium.csv")
	  public void T16_testManagerLogin(String testCaseNo, String username, String password, String UnError, String PassError) throws Exception {
	    
		  ecFunction.login(driver, username, password);
		  ecFunction.takeScreenshot(driver, "T16_testManagerLogin"+testCaseNo);
	    if (!CmnUtil.isNullorEmpty(UnError) || !CmnUtil.isNullorEmpty(PassError)) {
	    assertEquals(UnError, driver.findElement(By.xpath(prop.getProperty("Msg_Uname_Xpath"))).getText());
	    assertEquals(PassError, driver.findElement(By.xpath(prop.getProperty("Msg_Pass_Xpath"))).getText());
	    }
	    else {
	    	
	    	assertTrue(isElementPresent(By.xpath(prop.getProperty("Txt_ReservedEvents_Link"))));
	    	assertTrue(isElementPresent(By.linkText(prop.getProperty("Txt_Logout_Link"))));
	    	assertTrue(isElementPresent(By.linkText(prop.getProperty("Txt_EventCateringSys_Link"))));
	    	ecFunction.logout(driver);
		}
	  }
	 
	  
	  

	@Test
	@FileParameters("resources/manager_event_selenium.csv")
	public void T17_validateViewEventSummary(String testCaseNo, String username, String password, String date,
			String time) throws Exception {

		ecFunction.login(driver, username, password);
		driver.findElement(By.linkText(prop.getProperty("LINK_VIEW_ASSIGNED_TEXT_MNGR"))).click();
		String todaysDate = CmnUtil.getTodaysDate();
		String defaultDate = driver.findElement(By.xpath(prop.getProperty("ID_DATE_PICK"))).getAttribute("value");
		ecFunction.takeScreenshot(driver, "T17_validateViewEventSummary-A-" + testCaseNo);
		assertEquals(todaysDate, defaultDate);

		driver.findElement(By.xpath(prop.getProperty("ID_DATE_PICK"))).clear();
		driver.findElement(By.xpath(prop.getProperty("ID_DATE_PICK"))).sendKeys(date);
		driver.findElement(By.name(prop.getProperty("TF_NAME_STATRTIME"))).clear();
		driver.findElement(By.name(prop.getProperty("TF_NAME_STATRTIME"))).sendKeys(time);
		driver.findElement(By.cssSelector(prop.getProperty("BTN_CSS_SUBMIT"))).click();

		List<WebElement> rows = driver.findElement(By.xpath(prop.getProperty("TBLE_XPATH")))
				.findElements(By.tagName("tr"));
		Event event = new Event();
		event.setDate(date);
		event.setStartTime(time);
		List<Event> userEvents = EventDAO.getManagerEvents(event);
		assertEquals(userEvents.size(), rows.size() - 1);
		validateHeaders();
		List<Map<String, String>> tableData = getTableData(2, rows.size());
		assertTrue(valiadteSortOrder(tableData));
		assertTrue(compareDBResults(tableData, userEvents));
		for (int i = 2; i <= rows.size(); i++) {

			driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[8]/a")).click();
			assertEquals(userEvents.get(i - 2).getName(),
					driver.findElement(By.xpath(prop.getProperty("TD_MANAGER_NAME"))).getAttribute("value"));
			assertEquals(userEvents.get(i - 2).getDate(),
					driver.findElement(By.xpath(prop.getProperty("TD_MANAGER_DATE"))).getAttribute("value"));
			assertEquals(userEvents.get(i - 2).getStartTime(),
					driver.findElement(By.xpath(prop.getProperty("TD_MANAGER_STARTTIME"))).getAttribute("value"));
			assertEquals(userEvents.get(i - 2).getDuration(),
					new Select(driver.findElement(By.xpath(prop.getProperty("TD_MANAGER_DURATION"))))
							.getFirstSelectedOption().getAttribute("value"));
			assertEquals(userEvents.get(i - 2).getHallName(),
					driver.findElement(By.xpath(prop.getProperty("TD_MANAGER_HALLNAME"))).getAttribute("value"));
			assertEquals(userEvents.get(i - 2).getEstAttendees(),
					driver.findElement(By.xpath(prop.getProperty("TD_MANAGER_ATTENDEES"))).getAttribute("value"));
			assertEquals(userEvents.get(i - 2).getFoodType(),
					new Select(driver.findElement(By.xpath(prop.getProperty("TD_MANAGER_FOODTYPE"))))
							.getFirstSelectedOption().getAttribute("value"));
			assertEquals(userEvents.get(i - 2).getMeal(),
					new Select(driver.findElement(By.xpath(prop.getProperty("TD_MANAGER_MEAL"))))
							.getFirstSelectedOption().getAttribute("value"));
			assertEquals(userEvents.get(i - 2).getMealFormality(),
					new Select(driver.findElement(By.xpath(prop.getProperty("TD_MANAGER_MEALFORMALITY"))))
							.getFirstSelectedOption().getAttribute("value"));
			assertEquals(userEvents.get(i - 2).getDrinkType(),
					new Select(driver.findElement(By.xpath(prop.getProperty("TD_MANAGER_DRINKTYPE"))))
							.getFirstSelectedOption().getAttribute("value"));
			assertEquals(userEvents.get(i - 2).getEntertainmentItems(),
					new Select(driver.findElement(By.xpath(prop.getProperty("TD_MANAGER_ET")))).getFirstSelectedOption()
							.getAttribute("value"));
			assertEquals(userEvents.get(i - 2).getEventStatus(),
					new Select(driver.findElement(By.xpath(prop.getProperty("TD_MANAGER_STATUS"))))
							.getFirstSelectedOption().getAttribute("value"));
			assertEquals(Double.parseDouble(userEvents.get(i - 2).getEstCost()),
					Double.parseDouble(
							driver.findElement(By.xpath(prop.getProperty("TD_MANAGER_COST"))).getAttribute("value")),
					.01);

			List<WebElement> rowsAssignedStaff = driver
					.findElement(By.xpath(prop.getProperty("TBLE_XPATH_ASSIGNED_STAFF")))
					.findElements(By.tagName("tr"));
			String eventId = driver.findElement(By.xpath(prop.getProperty("TXT_EVENT_ID_HIDDEN")))
					.getAttribute("value");
			List<User> allStaff = UserDAO.getAssignedStaff(eventId);

			for (int k = 2; k < rowsAssignedStaff.size(); k++) {
				assertEquals(allStaff.get(k - 2).getFirstName(),
						driver.findElement(By.xpath("html/body/table[2]/tbody/tr[" + k + "]/td[1]")).getText());
				assertEquals(allStaff.get(k - 2).getLastName(),
						driver.findElement(By.xpath("html/body/table[2]/tbody/tr[" + k + "]/td[2]")).getText());
			}

			ecFunction.takeScreenshot(driver, "T17_validateViewEventSummary-B-" + testCaseNo + i);

			driver.navigate().back();
		}
		driver.findElement(By.linkText(prop.getProperty("TEXT_LOGOUT"))).click();

	}

	@Test
	@FileParameters("resources/manager_event_selenium.csv")
	public void T18_validateDeleteStaff(String testCaseNo, String username, String password, String date,
			String time) throws Exception {

		ecFunction.login(driver, username, password);
		driver.findElement(By.linkText(prop.getProperty("LINK_VIEW_ASSIGNED_TEXT_MNGR"))).click();

		driver.findElement(By.xpath(prop.getProperty("ID_DATE_PICK"))).clear();
		driver.findElement(By.xpath(prop.getProperty("ID_DATE_PICK"))).sendKeys(date);
		driver.findElement(By.name(prop.getProperty("TF_NAME_STATRTIME"))).clear();
		driver.findElement(By.name(prop.getProperty("TF_NAME_STATRTIME"))).sendKeys(time);
		driver.findElement(By.cssSelector(prop.getProperty("BTN_CSS_SUBMIT"))).click();

		List<WebElement> rows = driver.findElement(By.xpath(prop.getProperty("TBLE_XPATH")))
				.findElements(By.tagName("tr"));
		int i = 2;
		if (i <= rows.size()) {
			driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[8]/a")).click();

			while (driver.findElement(By.xpath(prop.getProperty("TBLE_XPATH_ASSIGNED_STAFF")))
					.findElements(By.tagName("tr")).size() > 1) {
				driver.findElement(By.linkText(prop.getProperty("LINK_MANAGER_STAFF_DELETE"))).click();
				assertTrue(closeAlertAndGetItsText().matches("^Are you sure you want to remove this user[\\s\\S]$"));
				assertTrue(driver.findElement(By.xpath(prop.getProperty("TXT_DELETE_MSG"))).getText()
						.contains(prop.getProperty("TXT_DELETE_MSG_SUCCESS")));
				ecFunction.takeScreenshot(driver, "T18_validateDeleteStaff" + testCaseNo+i);


			}

			driver.findElement(By.linkText(prop.getProperty("TEXT_LOGOUT"))).click();

		}

	}

	@Test
	@FileParameters("resources/manager_event_selenium.csv")
	public void T19_validateAssignStaff(String testCaseNo, String username, String password, String date, String time)
			throws Exception {

		ecFunction.login(driver, username, password);
		driver.findElement(By.linkText(prop.getProperty("LINK_VIEW_ASSIGNED_TEXT_MNGR"))).click();

		driver.findElement(By.xpath(prop.getProperty("ID_DATE_PICK"))).clear();
		driver.findElement(By.xpath(prop.getProperty("ID_DATE_PICK"))).sendKeys(date);
		driver.findElement(By.name(prop.getProperty("TF_NAME_STATRTIME"))).clear();
		driver.findElement(By.name(prop.getProperty("TF_NAME_STATRTIME"))).sendKeys(time);
		driver.findElement(By.cssSelector(prop.getProperty("BTN_CSS_SUBMIT"))).click();

		List<WebElement> rows = driver.findElement(By.xpath(prop.getProperty("TBLE_XPATH")))
				.findElements(By.tagName("tr"));
		int i = 2;
		if (i <= rows.size()) {
			driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[8]/a")).click();
			int k = new Select(driver.findElement(By.xpath(prop.getProperty("SLT_STAFF_NAME")))).getOptions().size();
			while (k > 0) {

				driver.findElement(By.cssSelector("body > form > input[type=\"submit\"]")).click();
				closeAlertAndGetItsText();
				ecFunction.takeScreenshot(driver, "T19_validateAssignStaff" + testCaseNo + k);
				k--;
			}
//			String eventId = driver.findElement(By.xpath(prop.getProperty("TXT_EVENT_ID_HIDDEN")))
//					.getAttribute("value");
//			assertTrue(UserDAO.getAllStaff(eventId).size() == 0);
		}

		driver.findElement(By.linkText(prop.getProperty("TEXT_LOGOUT"))).click();
	}

	private boolean compareDBResults(List<Map<String, String>> tableData, List<Event> userEvents) {
		for (int i = 0; i < userEvents.size(); i++) {
			if (!userEvents.get(i).getName().equals(tableData.get(i).get(HEADERS.get(0)))
					|| !userEvents.get(i).getDate().equals(tableData.get(i).get(HEADERS.get(1)))
					|| !userEvents.get(i).getStartTime().equals(tableData.get(i).get(HEADERS.get(2)))
					|| !userEvents.get(i).getDuration().equals(tableData.get(i).get(HEADERS.get(3)))
					|| !userEvents.get(i).getHallName().equals(tableData.get(i).get(HEADERS.get(4)))
					|| !userEvents.get(i).getEventStatus().equals(tableData.get(i).get(HEADERS.get(5)))) {
				return false;
			}
		}
		return true;
	}

	private List<Map<String, String>> getTableData(int start, int end) {
		List<Map<String, String>> list = new ArrayList<>();
		for (int i = start; i <= end; i++) {
			Map<String, String> map = new HashMap<String, String>();
			map.put(HEADERS.get(0),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[1]")).getText());
			map.put(HEADERS.get(1),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[2]")).getText());
			map.put(HEADERS.get(2),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[3]")).getText());
			map.put(HEADERS.get(3),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[4]")).getText());
			map.put(HEADERS.get(4),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[5]")).getText());
			map.put(HEADERS.get(5),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[6]")).getText());
			list.add(map);
		}
		return list;

	}

	private boolean valiadteSortOrder(List<Map<String, String>> tableData) {
		if (tableData.size() < 2)
			return true;
		Date dateTime = CmnUtil.getDateTime(tableData.get(0).get("Date"), tableData.get(0).get("Start Time"));
		for (int i = 1; i < tableData.size(); i++) {
			Map<String, String> array_element = tableData.get(i);
			Date dateTimeNew = CmnUtil.getDateTime(tableData.get(i).get("Date"), tableData.get(i).get("Start Time"));
			if (dateTimeNew.compareTo(dateTime) < 0) {
				return false;
			}
			dateTime = dateTimeNew;

		}
		return true;

	}

	private void validateHeaders() {
		List<String> pageHeaders = new ArrayList<String>();
		for (int i = 1; i <= 8; i++) {
			String header = driver.findElement(By.xpath("html/body/table/tbody/tr[1]/th[" + i + "]")).getText();
			pageHeaders.add(header);
		}
		assertArrayEquals(HEADERS.toArray(), pageHeaders.toArray());
	}

	
	

	@Test
	@FileParameters("resources/event_name_selenium.csv")
	public void T20_EventLastName(String testCaseNo, String id, String username, String date,
			String startTime, String duration, String hallName, String estAttendees, String name, String foodType,
			String meal, String mealFormality, String drinkType, String entertainmentItems, String eventStatus,
			String estCost, String error) throws Exception {
		ecFunction.login(driver, prop.getProperty("MANAGER_USERNAME"), prop.getProperty("MANAGER_PASSWORD"));
		ecFunction.eventsummary(driver, id, username, date, startTime, duration, hallName, estAttendees, name, foodType,
				meal, mealFormality, drinkType, entertainmentItems, eventStatus, estCost, error);
		assertEquals("are you sure you want to update event", closeAlertAndGetItsText());
		assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Event_Name_Err_xp"))).getText());
		ecFunction.takeScreenshot(driver, "T20_EventLastName" + testCaseNo);
	}

	@Test
	@FileParameters("resources/event_attendees_selenium.csv")
	public void T21_testManagerEventUpdateAttendees(String testCaseNo, String id, String username, String date,
			String startTime, String duration, String hallName, String estAttendees, String name, String foodType,
			String meal, String mealFormality, String drinkType, String entertainmentItems, String eventStatus,
			String estCost, String error) throws Exception {
		ecFunction.login(driver, prop.getProperty("MANAGER_USERNAME"), prop.getProperty("MANAGER_PASSWORD"));

		ecFunction.eventsummary(driver, id, username, date, startTime, duration, hallName, estAttendees, name, foodType,
				meal, mealFormality, drinkType, entertainmentItems, eventStatus, estCost, error);

		assertEquals("are you sure you want to update event", closeAlertAndGetItsText());

		assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Event_Attendees_Err_xp"))).getText());
		ecFunction.takeScreenshot(driver, "T21_testManagerEventUpdateAttendees" + testCaseNo);
	}

	@Test
	@FileParameters("resources/event_date_selenium.csv")
	public void T22_testManagerEventUpdateTime(String testCaseNo, String id, String username, String date,
			String startTime, String duration, String hallName, String estAttendees, String name, String foodType,
			String meal, String mealFormality, String drinkType, String entertainmentItems, String eventStatus,
			String estCost, String error, String past_error) throws Exception {
		ecFunction.login(driver, prop.getProperty("MANAGER_USERNAME"), prop.getProperty("MANAGER_PASSWORD"));

		ecFunction.eventsummary(driver, id, username, date, startTime, duration, hallName, estAttendees, name, foodType,
				meal, mealFormality, drinkType, entertainmentItems, eventStatus, estCost, error);

		assertEquals("are you sure you want to update event", closeAlertAndGetItsText());

		assertEquals(error, driver.findElement(By.xpath(prop.getProperty("Event_Time_Err_xp"))).getText());
		assertEquals(past_error, driver.findElement(By.xpath(prop.getProperty("Event_Date_Err_xp"))).getText());
		ecFunction.takeScreenshot(driver, "T22_testManagerEventUpdateTime" + testCaseNo);
	}



	@Test
	public void T23_testButtonLink() throws Exception {
		ecFunction.login(driver, prop.getProperty("MANAGER_USERNAME"), prop.getProperty("MANAGER_PASSWORD"));

		driver.findElement(By.cssSelector("span")).click();

		assertTrue(isElementPresent(By.linkText(prop.getProperty("Event_Catering_link"))));

		assertTrue(isElementPresent(By.linkText(prop.getProperty("Logout_Link"))));

		assertTrue(isElementPresent(By.cssSelector(prop.getProperty("Manager_Submit"))));

		ecFunction.managerdatepicker(driver, "2020-06-01", "07:00");

		driver.findElement(By.linkText(prop.getProperty("View_Event"))).click();

		assertTrue(isElementPresent(By.linkText(prop.getProperty("Event_Catering_link"))));

		assertTrue(isElementPresent(By.linkText(prop.getProperty("Logout_Link"))));

		assertTrue(isElementPresent(By.cssSelector(prop.getProperty("Manager_Submit"))));

		assertTrue(isElementPresent(By.linkText(prop.getProperty("Assigned_Staff"))));

		assertTrue(isElementPresent(By.linkText(prop.getProperty("Assign_Staff"))));

		driver.findElement(By.linkText(prop.getProperty("Logout_Link"))).click();
		ecFunction.takeScreenshot(driver, "T23_testButtonLink");


	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} catch (Exception e) {
			return "";
		} finally {
			acceptNextAlert = true;
		}
	}
}
