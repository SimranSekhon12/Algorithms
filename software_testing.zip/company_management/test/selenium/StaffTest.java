package selenium;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import cmn.EventCatering_Functions;
import event_management.data.EventDAO;
import event_management.model.Event;
import event_management.util.CmnUtil;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(JUnitParamsRunner.class)
public class StaffTest {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	EventCatering_Functions ecFunction;
	private static Properties prop = EventCatering_Functions.prop;
	private static List<String> HEADERS = Arrays.asList("Event Name", "Date", "Start Time", "Duration", "Hall Name",
			"Event Status", "Estimated Cost", "Action");

	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
		driver = new FirefoxDriver();
		baseUrl = prop.getProperty("BASE_URL");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		ecFunction = new EventCatering_Functions();
	}

	@Test
	@FileParameters("resources/username_login_selenium.csv")
	public void T01_testUsername(String testCaseNo, String username, String password, String unameError,
			String passError) throws Exception {
		ecFunction.login(driver, username, password);

		ecFunction.takeScreenshot(driver, "StaffLogin" + testCaseNo);

		if (!CmnUtil.isNullorEmpty(unameError) || !CmnUtil.isNullorEmpty(passError)) {
			assertEquals(unameError, driver.findElement(By.xpath(prop.getProperty("TXT_USERNAME_ERROR"))).getText());
			assertEquals(passError, driver.findElement(By.xpath(prop.getProperty("TXT_PASS_ERROR"))).getText());

		} else {
			assertTrue(isElementPresent(By.linkText(prop.getProperty("LINK_TEXT_LOGOUT"))));
			assertTrue(isElementPresent(By.linkText(prop.getProperty("LINK_TEXT_ASSIGN_EVENT_SUMMARY"))));
			assertTrue(isElementPresent(By.linkText(prop.getProperty("LINK_TEXT_HOMEPAGE"))));

		}

	}

	@Test
	@FileParameters("resources/staff_assigned_event_selenium.csv")
	public void T02_testViewAssignedEvent(String testCaseNo, String username, String password, String date, String time)
			throws Exception {

		ecFunction.login(driver, username, password);
		driver.findElement(By.linkText(prop.getProperty("LINK_VIEW_ASSIGNED_TEXT"))).click();
		String todaysDate = CmnUtil.getTodaysDate();
		String defaultDate = driver.findElement(By.xpath(prop.getProperty("ID_DATE_PICK"))).getAttribute("value");
		ecFunction.takeScreenshot(driver, "datedefault" + testCaseNo);
		assertEquals(todaysDate, defaultDate);

		driver.findElement(By.xpath(prop.getProperty("ID_DATE_PICK"))).clear();
		driver.findElement(By.xpath(prop.getProperty("ID_DATE_PICK"))).sendKeys(date);
		// driver.findElement(By.cssSelector(prop.getProperty("BTN_CSS_SUBMIT"))).click();
		driver.findElement(By.name(prop.getProperty("TF_NAME_STATRTIME"))).clear();
		driver.findElement(By.name(prop.getProperty("TF_NAME_STATRTIME"))).sendKeys(time);
		driver.findElement(By.cssSelector(prop.getProperty("BTN_CSS_SUBMIT"))).click();

		List<WebElement> rows = driver.findElement(By.xpath(prop.getProperty("TBLE_XPATH")))
				.findElements(By.tagName("tr"));
		Event event = new Event();
		event.setDate(date);
		event.setStartTime(time);
		List<Event> userEvents = EventDAO.getStaffEvents(username, event);
		assertEquals(userEvents.size(), rows.size() - 1);
		validateHeaders();
		List<Map<String, String>> tableData = getTableData(2, rows.size());
		assertTrue(valiadteSortOrder(tableData));
		assertTrue(compareDBResults(tableData, userEvents));
		for (int i = 2; i <= rows.size(); i++) {

			driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[8]/a")).click();
			assertEquals(userEvents.get(i - 2).getName(),
					driver.findElement(By.xpath(prop.getProperty("TD_STAFF_NAME"))).getText());
			assertEquals(userEvents.get(i - 2).getDate(),
					driver.findElement(By.xpath(prop.getProperty("TD_STAFF_DATE"))).getText());
			assertEquals(userEvents.get(i - 2).getStartTime(),
					driver.findElement(By.xpath(prop.getProperty("TD_STAFF_STARTTIME"))).getText());
			assertEquals(userEvents.get(i - 2).getDuration(),
					driver.findElement(By.xpath(prop.getProperty("TD_STAFF_DURATION"))).getText());
			assertEquals(userEvents.get(i - 2).getHallName(),
					driver.findElement(By.xpath(prop.getProperty("TD_STAFF_HALLNAME"))).getText());
			assertEquals(userEvents.get(i - 2).getEstAttendees(),
					driver.findElement(By.xpath(prop.getProperty("TD_STAFF_ATTENDEES"))).getText());
			assertEquals(userEvents.get(i - 2).getFoodType(),
					driver.findElement(By.xpath(prop.getProperty("TD_STAFF_FOODTYPE"))).getText());
			assertEquals(userEvents.get(i - 2).getMeal(),
					driver.findElement(By.xpath(prop.getProperty("TD_STAFF_MEAL"))).getText());
			assertEquals(userEvents.get(i - 2).getMealFormality(),
					driver.findElement(By.xpath(prop.getProperty("TD_STAFF_MEALFORMALITY"))).getText());
			assertEquals(userEvents.get(i - 2).getDrinkType(),
					driver.findElement(By.xpath(prop.getProperty("TD_STAFF_DRINKTYPE"))).getText());
			assertEquals(userEvents.get(i - 2).getEntertainmentItems(),
					driver.findElement(By.xpath(prop.getProperty("TD_STAFF_ET"))).getText());
			assertEquals(userEvents.get(i - 2).getEventStatus(),
					driver.findElement(By.xpath(prop.getProperty("TD_STAFF_STATUS"))).getText());
			assertEquals(Double.parseDouble(userEvents.get(i - 2).getEstCost()),
					Double.parseDouble(driver.findElement(By.xpath(prop.getProperty("TD_STAFF_COST"))).getText()), .01);
			ecFunction.takeScreenshot(driver, "T02_testViewAssignedEvent" + testCaseNo+i);
			driver.navigate().back();
		}
		driver.findElement(By.linkText(prop.getProperty("TEXT_LOGOUT"))).click();

	}

	private boolean compareDBResults(List<Map<String, String>> tableData, List<Event> userEvents) {
		for (int i = 0; i < userEvents.size(); i++) {
			if (!userEvents.get(i).getName().equals(tableData.get(i).get(HEADERS.get(0)))
					|| !userEvents.get(i).getDate().equals(tableData.get(i).get(HEADERS.get(1)))
					|| !userEvents.get(i).getStartTime().equals(tableData.get(i).get(HEADERS.get(2)))
					|| !userEvents.get(i).getDuration().equals(tableData.get(i).get(HEADERS.get(3)))
					|| !userEvents.get(i).getHallName().equals(tableData.get(i).get(HEADERS.get(4)))
					|| !userEvents.get(i).getEventStatus().equals(tableData.get(i).get(HEADERS.get(5)))) {
				return false;
			}
		}
		return true;
	}

	private List<Map<String, String>> getTableData(int start, int end) {
		List<Map<String, String>> list = new ArrayList<>();
		for (int i = start; i <= end; i++) {
			Map<String, String> map = new HashMap<String, String>();
			map.put(HEADERS.get(0),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[1]")).getText());
			map.put(HEADERS.get(1),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[2]")).getText());
			map.put(HEADERS.get(2),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[3]")).getText());
			map.put(HEADERS.get(3),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[4]")).getText());
			map.put(HEADERS.get(4),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[5]")).getText());
			map.put(HEADERS.get(5),
					driver.findElement(By.xpath("html/body/table/tbody/tr[" + i + "]/td[6]")).getText());
			list.add(map);
		}
		return list;

	}

	private boolean valiadteSortOrder(List<Map<String, String>> tableData) {
		if (tableData.size() < 2)
			return true;
		Date dateTime = CmnUtil.getDateTime(tableData.get(0).get("Date"), tableData.get(0).get("Start Time"));
		for (int i = 1; i < tableData.size(); i++) {
			Map<String, String> array_element = tableData.get(i);
			Date dateTimeNew = CmnUtil.getDateTime(tableData.get(i).get("Date"), tableData.get(i).get("Start Time"));
			if (dateTimeNew.compareTo(dateTime) < 0) {
				return false;
			}
			dateTime = dateTimeNew;

		}
		return true;

	}

	private void validateHeaders() {
		List<String> pageHeaders = new ArrayList<String>();
		for (int i = 1; i <= 8; i++) {
			String header = driver.findElement(By.xpath("html/body/table/tbody/tr[1]/th[" + i + "]")).getText();
			pageHeaders.add(header);
		}
		assertArrayEquals(HEADERS.toArray(), pageHeaders.toArray());
	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
