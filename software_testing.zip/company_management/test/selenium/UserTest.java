package selenium;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import cmn.EventCatering_Functions;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
@RunWith(JUnitParamsRunner.class)
public class UserTest {
	private WebDriver driver;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	private EventCatering_Functions function;
	private static Properties prop = EventCatering_Functions.prop;

	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
		driver = new FirefoxDriver();
		function = new EventCatering_Functions();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void T01_verifyLoginLinks() throws Exception {

		function.login(driver, prop.getProperty("USER_USERNAME"), prop.getProperty("USER_PASSWORD"));
		assertTrue(isElementPresent(By.linkText(prop.getProperty("Txt_EventCateringSys_Link"))));
		assertTrue(isElementPresent(By.linkText(prop.getProperty("TXT_LINK_REQUEST_AN_EVENT"))));
		assertTrue(isElementPresent(By.linkText(prop.getProperty("TXT_LINK_VIEW_ALL_EVENT"))));
		assertTrue(isElementPresent(By.linkText(prop.getProperty("TXT_LINK_VIEW_PROFILE_USER"))));
		function.takeScreenshot(driver, "T01_verifyLoginLinks");
		function.logout(driver);
		
	}

	@Test
	public void T02_viewUpdateProfile() throws Exception {
		function.login(driver, prop.getProperty("USER_USERNAME"), prop.getProperty("USER_PASSWORD"));
		driver.findElement(By.xpath(prop.getProperty("USER_VIEW_PROFILE_SPAN"))).click();
		driver.findElement(By.name("city")).clear();
		driver.findElement(By.cssSelector(prop.getProperty("BTN_CSS_SUBMIT"))).click();
		assertEquals("are you sure you want to update user", closeAlertAndGetItsText());
		driver.findElement(By.name("city")).sendKeys("DallasT");
		driver.findElement(By.cssSelector(prop.getProperty("BTN_CSS_SUBMIT"))).click();
		assertEquals("are you sure you want to update user", closeAlertAndGetItsText());
		function.takeScreenshot(driver, "T02_viewUpdateProfile");
		function.logout(driver);
	}

	 @Test
	 @FileParameters("resources/selenium/request_event.csv")
	public void T03_requestEvent(String testCaseNo, String id, String username, String date, String startTime,
			String duration, String hallName, String estAttendees, String name, String foodType, String meal,
			String mealFormality, String drinkType, String entertainmentItems, String eventStatus, String estCost,
			String nameError, String estAttendeesError, String startTimeError, String dateTimeError, String errorMsg,
			String hallnameError) {
		function.login(driver, prop.getProperty("USER_USERNAME"), prop.getProperty("USER_PASSWORD"));
		driver.findElement(By.cssSelector("span")).click();
		driver.findElement(By.id(prop.getProperty("Manager_Date_Picker"))).clear();
		driver.findElement(By.id(prop.getProperty("Manager_Date_Picker"))).sendKeys(date);
		driver.findElement(By.name(prop.getProperty("Manager_Start_Time"))).clear();
		driver.findElement(By.name(prop.getProperty("Manager_Start_Time"))).sendKeys(startTime);
		driver.findElement(By.name(prop.getProperty("Est_Attendees"))).clear();
		driver.findElement(By.name(prop.getProperty("Est_Attendees"))).sendKeys(estAttendees);
		new Select(driver.findElement(By.id(prop.getProperty("EVENT_DURATION_ID")))).selectByValue(duration);
		new Select(driver.findElement(By.id(prop.getProperty("EVENT_HALLNAME_ID")))).selectByValue(hallName);
		driver.findElement(By.name(prop.getProperty("Event_Name"))).clear();
		driver.findElement(By.name(prop.getProperty("Event_Name"))).sendKeys(name);
		new Select(driver.findElement(By.id(prop.getProperty("EVENT_FOODTYPE_ID")))).selectByValue(foodType);
		new Select(driver.findElement(By.id(prop.getProperty("EVENT_MEAL_ID")))).selectByValue(meal);
		new Select(driver.findElement(By.id(prop.getProperty("EVENT_MEALFORMALITY_ID")))).selectByValue(mealFormality);
		new Select(driver.findElement(By.id(prop.getProperty("EVENT_DRINKTYPE_ID")))).selectByValue(drinkType);
		new Select(driver.findElement(By.id(prop.getProperty("EVENT_ET_ID")))).selectByValue(entertainmentItems);
		driver.findElement(By.cssSelector(prop.getProperty("BTN_CSS_SUBMIT"))).click();
	
		if (!"success".equals(nameError)) {
			assertEquals(nameError,
					driver.findElement(By.xpath(prop.getProperty("NAME_ERROR_XPATH"))).getText());
			assertEquals(estAttendeesError,
					driver.findElement(By.xpath(prop.getProperty("EST_ETD_ERROR_XPATH"))).getText());
			assertEquals(startTimeError,
					driver.findElement(By.xpath(prop.getProperty("START_TIME_ERROR"))).getText());
			assertEquals(dateTimeError,
					driver.findElement(By.xpath(prop.getProperty("DATET_ERROR"))).getText());
			assertEquals(errorMsg, driver.findElement(By.xpath(prop.getProperty("GEN_ERROR_MSG"))).getText());
			assertEquals(hallnameError,
					driver.findElement(By.xpath(prop.getProperty("HALLNAME_ERROR"))).getText());

		}
		function.takeScreenshot(driver, "T03_requestEvent_"+testCaseNo);

		function.logout(driver);
	}/*8*************
	USER_CARDNUMBER_F=cardNumber
	USER_EXPDATE_ERROR=expDate
	USER_PIN_F=pin
	*
	*
	*/

	@Test
	public void T04_editEvent() {
		function.login(driver, prop.getProperty("USER_USERNAME"), prop.getProperty("USER_PASSWORD"));
		driver.findElement(By.xpath("html/body/div[2]/div/ul/li[2]/a/span")).click();
		driver.findElement(By.id(prop.getProperty("Manager_Date_Picker"))).clear();
		driver.findElement(By.id(prop.getProperty("Manager_Date_Picker"))).sendKeys("2020-07-03");
		driver.findElement(By.name(prop.getProperty("Manager_Start_Time"))).clear();
		driver.findElement(By.name(prop.getProperty("Manager_Start_Time"))).sendKeys("07:30");
		driver.findElement(By.cssSelector(prop.getProperty("BTN_CSS_SUBMIT"))).click();
		driver.findElement(By.linkText(prop.getProperty("Txt_ReservedEvent_Link_USER"))).click();
		driver.findElement(By.name(prop.getProperty("USER_CARDNUMBER_F"))).clear();
		driver.findElement(By.name(prop.getProperty("USER_CARDNUMBER_F"))).sendKeys("1234123412341234");
		driver.findElement(By.name(prop.getProperty("USER_EXPDATE_ERROR"))).clear();
		driver.findElement(By.name(prop.getProperty("USER_EXPDATE_ERROR"))).sendKeys("1234");
		driver.findElement(By.name(prop.getProperty("USER_PIN_F"))).clear();
		driver.findElement(By.name(prop.getProperty("USER_PIN_F"))).sendKeys("1234");
		driver.findElement(By.cssSelector(prop.getProperty("BTN_CSS_SUBMIT"))).click();
		driver.findElement(By.linkText("edit")).click();
		new Select(driver.findElement(By.id(prop.getProperty("EVENT_DRINKTYPE_ID")))).selectByVisibleText("alcohol");
		driver.findElement(By.cssSelector(prop.getProperty("BTN_CSS_SUBMIT"))).click();
		assertEquals("are you sure you want to update event", closeAlertAndGetItsText());
		driver.findElement(By.linkText("Event Catering System")).click();
		function.takeScreenshot(driver, "T04_editEvent");

		function.logout(driver);

	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by); 
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
