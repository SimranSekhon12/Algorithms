//Name - Simran Singh Sekhon
//ID - 1001669325

package ds_lab1;

//header files to be imported.
import java.util.*;
import java.net.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;

public class ClientChat extends JFrame implements ActionListener 
{
	//initiating required variables.
	String msg_line;
    String username;
    Socket client;
    BufferedReader read;
    PrintWriter write;
    JTextArea text_area;
    JTextField field_input;
    JButton send_btn, exit_btn;
    
    //constructor of ClientChat class.
	public ClientChat(String uname, String server) throws Exception 
	{
    super(uname);  //setting name of the user as title for the frame.
    this.username = uname;
    client  = new Socket(server,12345); //creating a new socket here on port number 12345.
    read = new BufferedReader( new InputStreamReader( client.getInputStream()) ) ; 
    write = new PrintWriter(client.getOutputStream(),true);
    write.println(uname);  //sending user's name to the server.
    Interface(); //calling interface method to build interface.
    new thread_message().start();  //creating a new thread for listening to messages.
	}//end of constructor.
    
    public void Interface() 
	{
		text_area = new JTextArea(); //creating new text area where we will display messages.
		text_area.setEditable(false);
		text_area.setColumns(40); //setting its width and height.
        text_area.setRows(20);
        
        //creating text field where we will type messages
        field_input  = new JTextField(75);
        //creating new buttons for sending messages and leaving session.
        send_btn = new JButton("Send");
        exit_btn = new JButton("Quit");
        
        //adding scroll bar.
        JScrollPane scroll = new JScrollPane(text_area, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        add(scroll,"Center");
        
        //adding the text field and buttons on to the panel in the interface.
        JPanel pan = new JPanel( new FlowLayout()); 
        pan.add(field_input);
        pan.add(send_btn);
        pan.add(exit_btn);
        add(pan,"South");
        
        //giving functionality to the buttons.
        send_btn.addActionListener(this); 
        exit_btn.addActionListener(this);
        //setting size and visibility.
        setVisible(true);
        setSize(400,200); 
        pack();
	}//end of interface() method.
    
    public void actionPerformed(ActionEvent eve) //this method is invoked when an action occurs.
	{
		if ( eve.getSource() == exit_btn ) 
		{
			System.out.println("a user left");  //tells server about client's wish to leave.
			System.exit(0);
		} 
		else 
		{
		//sending message to the server. This is HHTP encoding as per the assignment.
		StringBuilder head = new StringBuilder();
		String dateTime = new SimpleDateFormat("MM/dd/yyyy_HH:mm:ss").format(Calendar.getInstance().getTime());
		String message = field_input.getText();
        head.append("POST / HTTP/1.1 \t");
        head.append("Content-Length: 15 \t");
        head.append("Content-Type: text\t");
        head.append("Date: "+dateTime+"\t");
        head.append("Host: 10.182.37.168\t");
        head.append("User-Agent: Socket-Client\t");
        head.append("Sender: "+username);
        head.append("      message: "+message);	
		
        write.println(head);
		}
	}//end of action() method.
    
    //class for thread messages.
    public class thread_message extends Thread 
    {
        public void run() //when this thread is constructed using a separate Runnable run object, then that Runnable object's run method is called
        {
            try 
            {
                while(true) //here we are displaying the name of the user and its message on to the text area.
                {
                	msg_line = read.readLine();
                    System.out.println(msg_line);
                    String sender = msg_line.substring(msg_line.lastIndexOf("Sender:")).replace("Sender:", "");
                    String mess = msg_line.substring(msg_line.lastIndexOf("message:")).replace("message:", "");
                    text_area.append("-->" +sender+ "\n");
                }//end of while loop
			}//end of try
				catch(Exception exp) 
				{}
		}//end of run() method
	}//end of thread_message class
    
    public static void main(String[] args) //main method
	{
		String c_name = JOptionPane.showInputDialog(null,"Enter name : ", "Username", JOptionPane.PLAIN_MESSAGE); //taking input from user
		String s_name = "localhost";  
		try 
		{
			new ClientChat(c_name ,s_name); //passing the input received from user to the class
		} 
		catch(Exception exp) //catching and displaying exception.
		{
			System.out.println("Error: " + exp.getMessage());
		}
	}// end of main
    
}//end of ClientChat class and program