//Name - Simran Singh Sekhon
//ID - 1001669325

package ds_lab1;

//header files to be imported.
import java.util.*;
import java.net.*;
import java.io.*;

//This is the ServerChat class.
public class ServerChat 
{
	Vector <Handler> u_client = new Vector <Handler>(); 
	Vector <String> user = new Vector <String>();
	String msg_lines;

	public void session() throws Exception  
	{
		@SuppressWarnings("resource")
		ServerSocket server_socket = new ServerSocket(12345,5); //The chat server runs on port number 12345. We are creating a socket.
		System.out.println("The server has started.");
 
		while(true) //we are adding and handling clients here.
		{
		 Socket new_client = server_socket.accept(); 
		 Handler clt = new Handler(new_client);
		 u_client.add(clt);
		}
	}
	
		//here we send message to all the connected clients after checking it with if condition.
		public void broad(String u_name, String mess)  
		{
			for ( Handler clt : u_client )
			if ( !clt.getUserName().equals(user) )
	        clt.send(u_name,mess);
		}//end of broad() method
		
				//this is the main method where we initiate the server and create new server socket.
				public static void main(String[] args) throws Exception 
				{
					new ServerChat().session();
				}//end of main method. 
				
			//this is the Handler class where we are receiving input and output.
			public class Handler extends Thread 
			{ 
				String username = " ";
				BufferedReader input_stream; 
				PrintWriter output_stream;

				//constructor of Handler class.
				public Handler(Socket client) throws Exception 
				{   
					input_stream = new BufferedReader ( new InputStreamReader( client.getInputStream() ) ); //we are getting input stream here.
					output_stream = new PrintWriter (client.getOutputStream(),true); //we are getting output stream here.
					
					username = input_stream.readLine(); //we are reading the name here.
					user.add(username); //and adding it to the Vector String.
					start();
				}//end of constructor.

				public String getUserName() //this is returning the name of the user.
				{  
					return username; 
				}
				
				public void send(String uname, String message)  //this is giving output of name and message of the user.
				{
					output_stream.println(uname+": "+message);
				}
				
				public void run()  
				{
					try    
					{
						while(true)   
						{
							msg_lines = input_stream.readLine();
							if ( msg_lines.equals("end") ) 
							{
								u_client.remove(this);
								user.remove(username);
								break;
							} //if condition ends
							broad(username,msg_lines); //this is broad() method of ServerChat class which is sending messages to all.
						} //while loop ends
					} //try ends
						catch (Exception exp) //catching and displaying exception here.
						{
							System.out.println(exp.getMessage());
						}
				} //end of run() method
				
		} //end of Handler class

} //end of ServerChat class and program
