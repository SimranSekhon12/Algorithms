<?php
	$con = new mysqli('localhost', 'root','','petstore');
	if ($con->connect_error) {
		printf("Connect failed: %s\n", $con->connect_error);
		exit();
	}
?>