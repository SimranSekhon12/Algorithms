<?php
	$con = new mysqli('localhost', 'root','','petstore');
	if ($con->connect_error) {
		printf("Connect failed: %s\n", $con->connect_error);
		exit();
	}
?>
<!DOCTYPE html>
<html>
<head lang="en">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
<link rel="stylesheet" type="text/css" href="css/pet.css">

<title> Client </title>
</head>

<body>
	<div class="my-site">
	<header>
		<h1> Pet Store </h1>
	</header>
	<div class="main-body">
		<div class="leftContent">
			<nav class="nav"> 
				<a href='index.html'>Home</a> 
				<a href='AboutUs.html'>About Us</a>
				<a href='ContactUs.php'>Contact Us</a>
				<a href='Client.php'>Client</a>
				<a href='Service.php'>Service</a>
				<a href='Login.php'>Login</a>
			</nav>
		</div>

		<div class="rightContent">
			<div class="headbg"> </div>

		
			<div class="content">
				<h2> Client </h2>
				<p> Required information is marked with an asterisk (*).</p>

				<form id="usrform" method="POST" action=".\Client.php" onsubmit="validateForm()">
				<table class="table">

					<tr>
						<td>* First Name:</td>
						<td><input type="text" name="fname" required></td>
					</tr>

					<tr>
						<td>* Last Name:</td>
						<td><input type="text" name="lname" required></td>
					</tr>

					<tr>
						<td>* E-mail:</td>
						<td><input type="text" name="email" required></td>
					</tr>

					<tr>
						<td>* Phone:</td>
						<td><input type="text" name="phone" required></td>
					</tr>
					
					<tr>
						<td><input type="submit" value="Register" name="submit"></td>	
					</tr>
				</table>
				</form>

			</div>
			<footer>
				<small> <em>Copyright &copy; 2018 Pet Store</em></small> <br> 
				<a href='mailto:simran@sekhon.com'>simran@sekhon.com</a>
			</footer>
		</div>
	</div>
</div>
</body>
</html>

<?php
					
	if(isset($_POST['submit']))
	{
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$email=$_POST['email'];
		$phone=$_POST['phone'];
		
		if($fname=="")
		{
			echo "First Name is empty";
		}
		elseif ($email=="") {
		
		echo "Email is empty";
		}
		else
		{
			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  			echo "Invalid email format"; 
			}
			elseif (!preg_match("/^[a-zA-Z ]*$/",$fname)) {
			
			echo "Only letters and white space allowed in name";
			}
			else
			{
				#0 = business, 1= client
				$sql = "INSERT INTO `users`(`Role`, `firstName`, `lastName`, `email`, `phone`, `password`) VALUES (1,'$fname','$lname','$email','$phone','123456')";
				echo "<br><br><br><br>";
				
				
				if($con -> query($sql) ===TRUE)
				{	$subject = "password";
					$emailBody = "Your password is 123456";
					$header = "From:simran.sekhon10@gmail.com \r\n";
					 
					 $header .= "MIME-Version: 1.0\r\n";
					 $header .= "Content-type: text/html\r\n";
					
					echo "Records added";
					
					$retval = mail ($email,$subject,$emailBody,$header);
         
					 if( $retval == true ) {
						echo "Message sent successfully...";
					 }else {
						echo "Message could not be sent...";
					 }
					
					
				}
				else
				{
					echo $con->error;
					echo "Error : Add Error";
				}
				}
			}
		}

	mysqli_close($con);
?>