
<?php
require 'PHPMailerAutoload.php';

function sendEmail($recipient){
$mail = new PHPMailer();
$mail->IsSMTP(); // send via SMTP
IsSMTP(); // send via SMTP
$mail->SMTPAuth = true; // turn on SMTP authentication
$mail->Username = 'simran.sekhon10@gmail.com'; // Enter your SMTP username
$mail->Password = ”wisedemon“; // SMTP password
$webmaster_email = 'simran.sekhon10@gmail.com'; //Add reply-to email address
$email= $recipient; // Add recipients email address
$name=”name“; // Add Your Recipient’s name
$mail->From = $webmaster_email;
$mail->FromName = ”Webmaster”;
$mail->AddAddress($email,$name);
$mail->AddReplyTo($webmaster_email,”Webmaster”);
$mail->WordWrap = 50; // set word wrap
//$mail->AddAttachment(“/var/tmp/file.tar.gz”); // attachment
$mail->AddAttachment(“/tmp/image.jpg”, “new.jpg”); // attachment
$mail->IsHTML(true); // send as HTML

$mail->Subject = 'This is your subject';

$mail->Body =      'Hi, this is your new login password: 123456' ;      //HTML Body

//$mail->AltBody = 'Hi, this is your email body, etc, etc';     //Plain Text Body
if(!$mail->Send()){
echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
echo 'Message has been sent';
}
}
?>